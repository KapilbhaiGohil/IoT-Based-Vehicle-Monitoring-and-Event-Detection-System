require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const connectDB = require('./config/db');
const setupWebSocket = require('./sockets/wsHandler');
const telemetryRoutes = require('./routes/telemetryRoutes');

const app = express();

// Middleware
app.set('trust proxy', 1);
app.use(cors());
app.use(express.json());

// Routes
app.get('/health', (req, res) => {
    res.status(200).json({ status: "ok" });
});
app.use('/api', telemetryRoutes);

// Server setup
const server = http.createServer(app);
setupWebSocket(server);
const PORT = process.env.PORT || 8000;

connectDB()
    .then(() => {
        server.listen(PORT, () => {
            console.log(`Server running on port ${PORT}`);
            console.log(`WebSocket ready at /ws`);
        });
    })
    .catch((err) => {
        console.error("Database connection failed:", err);
        process.exit(1);
    });

// Error handlers
process.on('unhandledRejection', (err) => {
    console.error('Unhandled Rejection:', err);
});

process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
});